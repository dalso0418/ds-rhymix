<?php

class DB extends Rhymix\Framework\DB
{
	
}
