<?php

namespace Rhymix\Framework\Parsers\DBTable;

/**
 * Index class.
 */
class Index
{
	public $name;
	public $columns = array();
	public $type = null;
	public $options = null;
}
