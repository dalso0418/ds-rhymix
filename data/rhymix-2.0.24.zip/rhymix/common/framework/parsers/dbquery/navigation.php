<?php

namespace Rhymix\Framework\Parsers\DBQuery;

/**
 * Navigation class.
 */
class Navigation
{
	public $orderby = array();
	public $list_count;
	public $page_count;
	public $page;
	public $offset;
}
