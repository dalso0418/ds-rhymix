<?php

namespace Rhymix\Framework\Parsers\DBQuery;

/**
 * GroupBy class.
 */
class GroupBy
{
	public $columns = array();
	public $having = array();
	public $ifvar;
}
