<?php

namespace Rhymix\Framework;

/**
 * The exception class.
 */
class Exception extends \Exception
{
	
}
