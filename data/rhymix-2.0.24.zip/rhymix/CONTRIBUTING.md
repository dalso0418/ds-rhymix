# 개발에 참여하고 싶으신 분들께 드리는 안내문

이 파일의 내용은 공식 매뉴얼로 옮겨졌습니다.

- [이슈 및 PR 작성 방법](https://rhymix.org/manual/contrib/github)
- [코딩 규칙](https://rhymix.org/manual/contrib/coding-standards)
